package com.cjw.demo1_thirdlibrary;

/**
 * Created by Administrator on 2018/2/22.
 */

public class Calculator {

    static {
        System.loadLibrary("calculator-lib");
    }

    public static native int add(int a, int b);
}
