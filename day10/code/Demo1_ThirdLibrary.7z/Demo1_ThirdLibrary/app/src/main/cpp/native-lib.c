//
// Created by Administrator on 2018/2/22.
//

#include "com_cjw_demo1_thirdlibrary_Calculator.h"
#include <android/log.h>

#define TAG "cjw"

// int __android_log_print(int prio, const char* tag, const char* fmt, ...)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,TAG,__VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG,TAG,__VA_ARGS__)

int add(int a, int b) {
    LOGI("这是第三方库 %d %d", a, b);
    return a + b;
}

JNIEXPORT jint JNICALL Java_com_cjw_demo1_1thirdlibrary_Calculator_add
        (JNIEnv *env, jclass clazz, jint a, jint b) {
    return add(a, b);
}