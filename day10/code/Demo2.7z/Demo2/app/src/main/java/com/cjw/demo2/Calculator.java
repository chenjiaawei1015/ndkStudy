package com.cjw.demo2;

/**
 * Created by Administrator on 2018/2/22.
 */

public class Calculator {

    static {
        System.loadLibrary("native-lib");
    }

    public static native int add(int a, int b);

}
