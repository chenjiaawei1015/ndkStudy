package com.cjw.demo2;

import android.content.Context;
import android.widget.Toast;

/**
 * Created by Administrator on 2018/2/22.
 */

public class ToastUtils {

    public static void shortToast(Context context, String text) {
        Toast.makeText(context, text, Toast.LENGTH_SHORT).show();
    }
}
