package com.cjw.demo2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText mNum1Et;
    private EditText mNum2Et;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mNum1Et = findViewById(R.id.num1_et);
        mNum2Et = findViewById(R.id.num2_et);
    }

    public void calc(View view) {
        int num1 = Integer.parseInt(mNum1Et.getText().toString().trim());
        int num2 = Integer.parseInt(mNum2Et.getText().toString().trim());

        int res = Calculator.add(num1, num2);
        ToastUtils.shortToast(this, String.valueOf(res));
    }
}
