//
// Created by Administrator on 2018/2/22.
//

#ifndef DEMO2_CALCULATOR_H
#define DEMO2_CALCULATOR_H

extern int add(int a, int b);

#endif //DEMO2_CALCULATOR_H
