//
// Created by Administrator on 2018/2/22.
//

#include "com_cjw_demo2_Calculator.h"
#include "calculator.h"

JNIEXPORT jint JNICALL Java_com_cjw_demo2_Calculator_add
        (JNIEnv *env, jclass clazz, jint a, jint b) {
    return add(a, b);
}