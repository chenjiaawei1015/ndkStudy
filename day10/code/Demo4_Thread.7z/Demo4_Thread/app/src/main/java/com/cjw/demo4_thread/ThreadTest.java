package com.cjw.demo4_thread;

/**
 * Created by Administrator on 2018/2/22.
 */

public class ThreadTest {

    static {
        System.loadLibrary("native-lib");
    }

    public static native void threadIdTest();
    
}
