//
// Created by Administrator on 2018/2/22.
//

#include "com_cjw_demo4_thread_ThreadTest.h"
#include "com_cjw_demo4_thread_MainActivity.h"
#include <android/log.h>
#include <pthread.h>

// int __android_log_print(int prio, const char* tag, const char* fmt, ...)

#define TAG "cjw"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

JNIEXPORT void JNICALL Java_com_cjw_demo4_1thread_ThreadTest_threadIdTest
        (JNIEnv *env, jclass jclazz) {
    LOGI("thread test begin");
}

// JavaVM 只有一个
JavaVM *g_jvm = NULL;
// 调用jni方法的对象,用于回调
jobject g_obj = NULL;

void *handleError();

JNIEXPORT void JNICALL Java_com_cjw_demo4_1thread_MainActivity_setJniEnv
        (JNIEnv *env, jobject jobj) {
    // 保存 jvm 与 jobj

    // 获取 JAVAVM
    (*env)->GetJavaVM(env, &g_jvm);
    // 保存对象
    g_obj = (*env)->NewGlobalRef(env, jobj);
}

void *thread_fun(void *arg) {
    JNIEnv *env;

    // 自己定义的线程,需要创建 JNIEnv
    if ((*g_jvm)->AttachCurrentThread(g_jvm, &env, NULL) != JNI_OK) {
        LOGI("%s AttachCurrentThread failed", __FUNCTION__);
        return NULL;
    }

    jclass cls = (*env)->GetObjectClass(env, g_obj);
    if (cls == NULL) {
        LOGI("GetObjectClass null");

        return handleError();

    } else {
        LOGI("callback begin");
        jmethodID static_mid, default_mid;

        static_mid = (*env)->GetStaticMethodID(env, cls, "jniCallBack1", "(I)V");
        if (static_mid == NULL) {
            LOGI("static method null");
            return handleError();
        }
        (*env)->CallStaticVoidMethod(env, cls, static_mid, (int) arg);

        default_mid = (*env)->GetMethodID(env, cls, "jniCallBack2", "(I)V");
        if (default_mid == NULL) {
            LOGI("method id null");
            return handleError();
        }
        (*env)->CallVoidMethod(env, g_obj, default_mid, (int) arg);
    }
}

void *handleError() {
    if ((*g_jvm)->DetachCurrentThread(g_jvm) != JNI_OK) {
        LOGI("%s DetachCurrentThread", __FUNCTION__);
    }
    // 当前线程退出
    pthread_exit(0);
}

JNIEXPORT void JNICALL Java_com_cjw_demo4_1thread_MainActivity_newJniThread
        (JNIEnv *env, jobject jobj) {
    // 开启线程
    // 需要引入头文件 #include <pthread.h>

    LOGI("new thread begin");

    int i;
    // 定义5个线程
    pthread_t pt[5];
    for (i = 0; i < 5; ++i) {
        pthread_create(&pt[i], NULL, &thread_fun, (void *) i);
    }
}