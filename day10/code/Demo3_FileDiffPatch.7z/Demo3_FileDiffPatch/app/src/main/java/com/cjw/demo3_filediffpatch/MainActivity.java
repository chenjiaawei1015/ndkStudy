package com.cjw.demo3_filediffpatch;

import android.Manifest;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.tbruyelle.rxpermissions2.RxPermissions;

import java.io.File;

import io.reactivex.functions.Consumer;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "cjw";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        requestPermission();
    }

    public void diff(View view) {
        File storageDirectory = Environment.getExternalStorageDirectory();
        File sourceFile = new File(storageDirectory, "p1.jpg");
        String path = sourceFile.getAbsolutePath();

        String pathPattern = new File(storageDirectory, "p1_%d.jpg")
                .getAbsolutePath();

        FileUtils.diff(path, pathPattern, 3);
    }

    public void patch(View view) {
        File storageDirectory = Environment.getExternalStorageDirectory();
        File destFile = new File(storageDirectory, "p1_merge.jpg");
        String path = destFile.getAbsolutePath();

        String pathPattern = new File(storageDirectory, "p1_%d.jpg")
                .getAbsolutePath();

        FileUtils.patch(path, pathPattern, 3);
    }

    private void requestPermission() {
        RxPermissions permissions = new RxPermissions(this);
        permissions.request(Manifest.permission.READ_EXTERNAL_STORAGE)
                .subscribe(new Consumer<Boolean>() {
                    @Override
                    public void accept(Boolean aBoolean) throws Exception {
                        if (aBoolean) {
                            Log.d(TAG, "权限申请成功");
                        } else {
                            Log.d(TAG, "权限申请失败");
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.d(TAG, "权限申请异常 : " + GsonUtils.toString(throwable));
                    }
                });
    }
}
