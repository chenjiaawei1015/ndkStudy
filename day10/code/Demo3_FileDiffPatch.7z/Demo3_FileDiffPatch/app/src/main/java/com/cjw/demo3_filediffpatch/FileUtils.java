package com.cjw.demo3_filediffpatch;

/**
 * Created by Administrator on 2018/2/22.
 */

public class FileUtils {

    static {
        System.loadLibrary("native-lib");
    }

    public static native void diff(String path, String pathPattern, int fileNum);

    public static native void patch(String destPath, String pathPattern, int fileNum);
}
