package com.cjw.demo3_filediffpatch;

import com.google.gson.Gson;

/**
 * Created by Administrator on 2018/2/22.
 */

public class GsonUtils {

    public static String toString(Object obj) {
        Gson gson = new Gson();
        return gson.toJson(obj);
    }
}
