//
// Created by Administrator on 2018/2/22.
//

#include "com_cjw_demo3_filediffpatch_FileUtils.h"
#include <android/log.h>
#include <stdlib.h>

// int __android_log_print(int prio, const char* tag, const char* fmt, ...)

#define TAG "cjw"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__);

// 获取文件的大小
long get_file_size(char *path) {
    FILE *fp = fopen(path, "rb");
    fseek(fp, 0, SEEK_END);
    long size = ftell(fp);
    fclose(fp);
    return size;
}

JNIEXPORT void JNICALL Java_com_cjw_demo3_1filediffpatch_FileUtils_diff
        (JNIEnv *env, jclass clazz, jstring path, jstring path_pattern, jint file_num) {
    LOGI("diff begin");
    char *path_c = (char *) (*env)->GetStringUTFChars(env, path, NULL);
    char *path_pattern_c = (char *) (*env)->GetStringUTFChars(env, path_pattern, NULL);

    // 根据传入的拆分个数,设置每个文件的名称
    char **diff_files = (char **) malloc(sizeof(char *) * file_num);

    int i = 0;
    for (; i < file_num; ++i) {
        diff_files[i] = (char *) malloc(100);
        sprintf(diff_files[i], path_pattern_c, i);
        LOGI("file name %d : %s", i, diff_files[i]);
    }

    // 获取文件的大小
    long file_size = get_file_size(path_c);
    LOGI("file size : %ld", file_size);

    // 文件的索引
    int file_index = 0;

    FILE *source_fp = fopen(path_c, "rb");

    if (file_size % file_num == 0) {
        // 平分文件
        long each_size = file_size / file_num;
        // 文件大小索引
        long each_size_index = 0;
        for (; file_index < file_num; ++file_index) {
            each_size_index = 0;

            FILE *each_fp = fopen(diff_files[file_index], "wb");

            for (; each_size_index < each_size; ++each_size_index) {
                int file_ch = fgetc(source_fp);
                fputc(file_ch, each_fp);
            }

            fclose(each_fp);
        }
    } else {
        long each_size = file_size / file_num;
        long last_size = file_size - each_size * (file_num - 1);

        // 文件大小索引
        long each_size_index = 0;
        for (; file_index < file_num - 1; ++file_index) {
            each_size_index = 0;

            FILE *each_fp = fopen(diff_files[file_index], "wb");
            for (; each_size_index < each_size; ++each_size_index) {
                int file_ch = fgetc(source_fp);
                fputc(file_ch, each_fp);
            }
            fclose(each_fp);
        }

        each_size_index = 0;
        // 最后一个文件
        FILE *each_fp = fopen(diff_files[file_num - 1], "wb");
        for (; each_size_index < last_size; ++each_size_index) {
            int file_ch = fgetc(source_fp);
            fputc(file_ch, each_fp);
        }
        fclose(each_fp);
    }
    fclose(source_fp);

    LOGI("文件拆分结束");

    // 释放内存
    i = 0;
    for (; i < file_num; ++i) {
        free(diff_files[i]);
        diff_files[i] = NULL;
    }

    free(diff_files);
    diff_files = NULL;

    (*env)->ReleaseStringUTFChars(env, path, path_c);
    (*env)->ReleaseStringUTFChars(env, path_pattern, path_pattern_c);
}

JNIEXPORT void JNICALL Java_com_cjw_demo3_1filediffpatch_FileUtils_patch
        (JNIEnv *env, jclass clazz, jstring dest_path, jstring path_pattern, jint file_num) {
    LOGI("patch begin");
    char *dest_path_c = (char *) (*env)->GetStringUTFChars(env, dest_path, NULL);
    char *path_pattern_c = (char *) (*env)->GetStringUTFChars(env, path_pattern, NULL);

    // 根据传入的拆分个数,设置每个文件的名称
    char **diff_files = (char **) malloc(sizeof(char *) * file_num);

    int i = 0;
    for (; i < file_num; ++i) {
        diff_files[i] = (char *) malloc(100);
        sprintf(diff_files[i], path_pattern_c, i);
        LOGI("file name %d : %s", i, diff_files[i]);
    }

    FILE *dest_fp = fopen(dest_path_c, "wb");
    i = 0;
    long file_size_index;
    long file_size;
    for (; i < file_num; ++i) {
        file_size_index = 0;
        file_size = get_file_size(diff_files[i]);
        LOGI("file size %d : %ld", i, file_size);
        FILE *each_file = fopen(diff_files[i], "rb");
        for (; file_size_index < file_size; ++file_size_index) {
            fputc(fgetc(each_file), dest_fp);
        }
        fclose(each_file);
    }

    fclose(dest_fp);

    // 释放内存
    i = 0;
    for (; i < file_num; ++i) {
        free(diff_files[i]);
        diff_files[i] = NULL;
    }

    free(diff_files);
    diff_files = NULL;

    LOGI("文件合并结束");
    (*env)->ReleaseStringUTFChars(env, dest_path, dest_path_c);
    (*env)->ReleaseStringUTFChars(env, path_pattern, path_pattern_c);
}