package com.cjw.demo1;

/**
 * 文件工具类
 * Created by Administrator on 2018/2/18.
 */

public class FileUtils {

    static {
        System.loadLibrary("native-lib");
    }

    /**
     * 文件拆分
     *
     * @param path        路径
     * @param patternPath 生成路径
     * @param fileNum     拆分个数
     */
    public static native void diff(String path, String patternPath, int fileNum);

    public static void test() {

    }

}
