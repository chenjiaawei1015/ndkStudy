package com.cjw.demo1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "cjw";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // PathClassLoader
        ClassLoader classLoader = getClassLoader();
        Log.d(TAG, "classloader : " + classLoader.toString());

        // /system/lib;/vendor/lib
        // 代表如果so库如果没有放到应用中,会从 /system/lib 和 /vendor/lib 两个目录进行查找
        String pathProperty = System.getProperty("java.library.path");
        Log.d(TAG, "path : " + pathProperty);

        diff();
    }

    public void diff() {
        FileUtils.diff("", "", 3);
    }

}
