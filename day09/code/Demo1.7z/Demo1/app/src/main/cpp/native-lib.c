//
// Created by Administrator on 2018/2/18.
//

#include "com_cjw_demo1_FileUtils.h"
#include <android/log.h>
#include <assert.h>

// int __android_log_print(int prio, const char* tag, const char* fmt, ...)

#define TAG "cjw"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

#define NELEM(x) ((int)(sizeof(x)/sizeof((x)[0])))

// 静态注册
//JNIEXPORT void JNICALL Java_com_cjw_demo1_FileUtils_diff
//        (JNIEnv *env, jclass jcls, jstring path, jstring pattern_path, jint file_num) {
//
//    LOGI("jni begin");
//}

// 动态注册
JNIEXPORT void JNICALL native_diff
        (JNIEnv *env, jclass jcls, jstring path, jstring pattern_path, jint file_num) {

    LOGI("jni begin");
}

static const JNINativeMethod gMethods[] = {
        {
                "diff", // 方法名
                "(Ljava/lang/String;Ljava/lang/String;I)V", // 参数类型+返回值
                (void *) native_diff  // (void*)方法名
        }
};

static int registerNatives(JNIEnv *env) {
    LOGI("registerNatives begin");
    jclass clazz;
    clazz = (*env)->FindClass(env, "com/cjw/demo1/FileUtils");

    if (clazz == NULL) {
        LOGI("clazz is null");
        return JNI_FALSE;
    }

    jint res = (*env)->RegisterNatives(env, clazz, gMethods, NELEM(gMethods));
    if (res < 0) {
        LOGI("RegisterNatives return null");
        return JNI_FALSE;
    }
    return JNI_TRUE;
}

JNIEXPORT jint JNI_OnLoad(JavaVM *vm, void *reserved) {
    LOGI("JNI_OnLoad begin");

    JNIEnv *env = NULL;
    jint result = -1;

    if ((*vm)->GetEnv(vm, (void **) &env, JNI_VERSION_1_4) != JNI_OK) {
        LOGI("GetEnv failed");
        return -1;
    }
    assert(env != NULL);

    registerNatives(env);
    return JNI_VERSION_1_4;
}