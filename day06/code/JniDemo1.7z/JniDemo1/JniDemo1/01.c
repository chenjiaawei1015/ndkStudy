#include "stdafx.h"
// ����ͷ�ļ�
#include "JniMain.h"
#include <string.h>

JNIEXPORT jstring JNICALL Java_JniMain_getStringFromC
(JNIEnv *env, jclass jcls){
	char* c_str = "c string";
	// �� C �е� string ת��Ϊ jstring ���з���
	return (*env)->NewStringUTF(env, c_str);
}

JNIEXPORT jstring JNICALL Java_JniMain_getStringFromC2
(JNIEnv *env, jobject jobj){
	char* c_str = "c string2";
	return (*env)->NewStringUTF(env, c_str);
}

JNIEXPORT void JNICALL Java_JniMain_changeJavaStaticFieldValueFromC1
(JNIEnv *env, jobject jobj){
	jclass jcls = (*env)->GetObjectClass(env, jobj);

	jfieldID field_id = (*env)->GetStaticFieldID(env, jcls, "key1", "Ljava/lang/String;");
	jstring jstr = (*env)->GetStaticObjectField(env, jcls, field_id);

	char* c_str = (*env)->GetStringUTFChars(env, jstr, NULL);
	strcat(c_str, ", Change From C");

	jstring change_jstr = (*env)->NewStringUTF(env, c_str);
	(*env)->SetStaticObjectField(env, jcls, field_id, change_jstr);

	(*env)->ReleaseStringUTFChars(env, change_jstr, c_str);
}

JNIEXPORT void JNICALL Java_JniMain_changeJavaFieldValueFromC2
(JNIEnv *env, jobject jobj){
	// ��ȡ jclass 
	jclass jclazz = (*env)->GetObjectClass(env, jobj);
	// ��ȡ fieldId
	jfieldID field_id = (*env)->GetFieldID(env, jclazz, "key2", "Ljava/lang/String;");
	// ��ȡ jstring
	jstring jstr = (*env)->GetObjectField(env, jobj, field_id);

	// �����Ҫ�޸�ֵ , ��Ҫ�� jstring ת��Ϊ char*
	char* c_str = (*env)->GetStringUTFChars(env, jstr, NULL);
	strcat(c_str, ", Change From C");

	// ���½� char* ת��Ϊ jstring
	jstring jstr_new = (*env)->NewStringUTF(env, c_str);

	// ���µ�ֵ�������ø� JAVA
	(*env)->SetObjectField(env, jobj, field_id, jstr_new);

	// �ͷ� C �����������
	// GetStringUTFChars
	(*env)->ReleaseStringChars(env, jstr_new, c_str);
}