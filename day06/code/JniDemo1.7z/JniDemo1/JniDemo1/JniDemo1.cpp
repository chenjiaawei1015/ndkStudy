//// JniDemo1.cpp : �������̨Ӧ�ó������ڵ㡣
////
//
//#include "stdafx.h"
//#include <stdlib.h>
//#include <string.h>
//#include "JniMain.h"
//
//JNIEXPORT jstring JNICALL Java_JniMain_getStringFromC
//(JNIEnv *env, jclass jcls){
//	char* str = "c++ string";
//	return env->NewStringUTF(str);
//}